@extends('layouts.app') <!-- Extend the layout -->
@section('content')
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<!-- Page-specific content -->
<div class="container ward_anugaman_page">
    sdadasdasdsa

    <!-- Hidden template for new rows -->
</div>
@endsection

@section('scripts')
@endsection