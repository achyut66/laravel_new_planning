 <!-- Extend the layout -->
<?php $__env->startSection('content'); ?>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<style>
    /* Custom CSS for hover dropdown */
    .hover-dropdown:hover .dropdown-menu {
        display: block;
        background-color: #2B55F8;
    }

    .dropdown-menu {
        display: none;
        /* Hide by default */
    }
</style>
<!-- Page-specific content -->
<div class="container ward_anugaman_page">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card" style="background-color:white;border-radius:5px;">
        <div class="card-header heading">योजना कार्यक्रम विवरण गर्नुहोस</div>
        <div class="card-body">
            <!-- Form starts here -->
            <form action="<?php echo e(route('upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <table class="table table-bordered striped">
                    <tr>
                        <th>दर्ता.नं</th>
                        <th>राजपत्र नं .</th>
                        <th>योजनाको नाम</th>
                        <th>वार्ड नं</th>
                        <th>बिषयगत क्षेत्र</th>
                        <th>शिर्षकगत किसिम</th>
                        <th>बिनियोजन किसिम</th>
                        <th>अनुदान किसिम</th>
                        <th>बिनियोजन श्रोत</th>
                        <th>अनुदान रकम</th>
                        <th>बजेट शिर्षक नं</th>
                        <th>बजेट श्रोत</th>
                        <th>#</th>
                    </tr>
                    <!-- <?php
                        if (!empty($w_result)) {
                            foreach ($w_result as $w):
                                $name = "ward";
                            endforeach;
                        } elseif (!empty($n_result)) {
                            foreach ($n_result as $n):
                                $name = "nagar";
                            endforeach;
                        } else {
                            $name = "nabhariyeko";
                        }
                    ?> -->
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="dropdown hover-dropdown">
                                    <button class="btn btn-success" type="button" id="dropdownMenuButton"
                                        aria-expanded="false">
                                        <?php echo e($d['id']); ?>

                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <li><a class="dropdown-item"
                                                href="<?php echo e(route('ward_anugamans.index', ['id' => $d['id']])); ?>">वार्ड
                                                अनुगमन</a></li>
                                        <li><a class="dropdown-item"
                                                href="<?php echo e(route('nagar_anugamans.index', ['id' => $d['id']])); ?>">नगर
                                                अनुगमन</a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                            <td><?php echo e($d['rajpatra_no']); ?></td>
                            <td><?php echo e($d['program_name']); ?></td>
                            <td><?php echo e($d['p_ward']); ?></td>
                            <td><?php echo e($d['bishaygat_chhetra']); ?></td>
                            <td><?php echo e($d['shirshak_kisim']); ?></td>
                            <td><?php echo e($d['biniyojan_kisim']); ?></td>
                            <td><?php echo e($d['anudan_kisim']); ?></td>
                            <td><?php echo e($d['biniyojan_shrot']); ?></td>
                            <td><?php echo e($d['anudan_rakam']); ?></td>
                            <td><?php echo e($d['bajet_shirshak']); ?></td>
                            <td><?php echo e($d['bajet_shrot']); ?></td>
                            <td><a href="<?php echo e(route('yojanaupload.seeDetails', ['darta_no' => $d['id']])); ?>"
                                    class="btn btn-primary"><i class="fa fa-eye"></i></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </form>
            <div class="pagination">
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>
</div>
<!-- Hidden template for new rows -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ysystem\nyojana\resources\views/yojanaupload/view_all_plans.blade.php ENDPATH**/ ?>