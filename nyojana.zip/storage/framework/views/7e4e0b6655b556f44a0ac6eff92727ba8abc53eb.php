 <!-- Extend the layout -->
<?php $__env->startSection('content'); ?>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<!-- Page-specific content -->
<div class="container ward_anugaman_page">
    <div class="card" style="background-color:white;border-radius:5px;">
        <div class="card-header heading"><span style="margin-left:120px;">वडा स्तरीय अनुगमन विवरण</span> <span style="margin-left:80px;">
        <a href="<?php echo e(route('ward_anugamans.printView', ['darta_no' => $wardAnugaman->darta_no])); ?>">
            <button class="btn btn-success">PRINT</button>
        </a>
        <div class="card-body">
            <!-- Form starts here -->
            <!-- <form action="<?php echo e(route('ward_anugamans.store')); ?>" method="POST"> -->
            <?php echo csrf_field(); ?>
            <table class="table table-bordered striped">
                <label>योजनाको नाम: <u><?php echo e($wardAnugaman['program_name']); ?></u></label> 
                <span style="margin-left:25px;">योजना दर्ता नं: <u><?php echo e($wardAnugaman['darta_no']); ?></u></span>
                <span style="margin-left:25px;"><label>वडा नं: <u><?php echo e($wardAnugaman['p_ward']); ?></u> </label></span>
                <thead>
                    <tr>
                        <th>सी.नं</th>
                        <th>पद</th>
                        <th>नाम</th>
                        <th>वडा नं</th>
                        <th>नागरिकता नं.</th>
                        <th>जारि जिल्ला</th>
                        <th>जारि मिति</th>
                        <th>#</th>
                    </tr>
                </thead>
                <?php
$i = 1; // Initialize counter outside the loop
                ?>

                <?php $__currentLoopData = $wardAnugamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
    // Determine the post name translation based on post_name
    if ($wa->post_name == 1) {
        $new_val = "अध्यक्ष"; // "adakshy"
    } elseif ($wa->post_name == 2) {
        $new_val = "सचिव"; // "sachib"
    }elseif($wa->post_name == 3){
        $new_val = "कोशाध्यक्ष";
    }elseif($wa->post_name == 4){
        $new_val = "संयोजक";
    }else{
        $new_val = "सदस्य";
    }
                                ?>

                                <tr>
                                    <td><?php echo e($i++); ?></td> <!-- Increment counter here -->
                                    <td><?php echo e($new_val); ?></td>
                                    <td><?php echo e($wa['name']); ?></td>
                                    <td><?php echo e($wa['p_ward']); ?></td>
                                    <td><?php echo e($wa['cit_no']); ?></td>
                                    <td><?php echo e($wa['issued_district']); ?></td>
                                    <td><?php echo e($wa['issued_date']); ?></td>
                                    <td><button class="btn btn-warning">EDIT</button></td>
                                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            <!-- </form> -->
        </div>
    </div>
</div>

<!-- Hidden template for new rows -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ysystem\nyojana\resources\views/ward_anugaman/show_anugaman.blade.php ENDPATH**/ ?>