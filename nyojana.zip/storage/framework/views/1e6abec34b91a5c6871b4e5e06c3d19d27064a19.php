 <!-- Extend the layout -->
<?php $__env->startSection('content'); ?>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<!-- Page-specific content -->
<div class="container ward_anugaman_page">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card" style="background-color:white;border-radius:5px;">
        <div class="card-header heading">योजना कार्यक्रम दर्ता गर्नुहोस</div>
        <div class="card-body">
            <!-- Form starts here -->
            <form action="<?php echo e(route('upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <label class="inputname">योजना Upload गर्नुहोस :
                                <input type="file" accept=".xlsx, .xls" required name="file">
                            </label>
                        </div>
                        <div class="col-md-4">
                            <label class="inputname">स्याम्पल Download :
                                <a href="<?php echo e(asset('sample/excel_demo.xlsx')); ?>" class="btn btn-primary"
                                    download>Download Sample</a>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="givespace"></div>
                <div class="text-center">
                    <button class="btn btn-success" type="submit">Upload गर्नुहोस</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Hidden template for new rows -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ysystem\nyojana\resources\views/yojanaupload/yojanalist.blade.php ENDPATH**/ ?>